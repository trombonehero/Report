#!/bin/csh

set j = 0
set STARTTIME=`date +%s`
 while($j < 60)
	echo $j
	/usr/home/sug670/Desktop/capsh/build/src/capsh cat /usr/home/sug670/Downloads/TestingFiles/Android_Proximity.txt usr/home/sug670/Desktop/capsh/build/src/capsh cat /usr/home/sug670/Downloads/TestingFiles/bibs.txt
	@ j++
set ENDTIME=`date +%s`
set TIMEDIFF=`(echo "$ENDTIME - $STARTTIME") | bc | awk -F"." '{print $1"."substr($2,1,3)}'`
echo "Time diff is: $TIMEDIFF"
end


