/**
 *  Stanley Uche Godfrey
 *  The code is not working at the moment 
 *  But can pass as a Pseudo code
 * **/
package heartbeatpkg;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.atomic.*;

public class HeartBeatSort  {
		Integer[] numbers= new Integer[180];
		Integer counter= 0;
		int bigIndex=0,length=20;
		AtomicBoolean[]allSorted ;
		HeartBeatThreads [][] hbtArray;
		public HeartBeatSort(){
			hbtArray= new HeartBeatThreads[3][3];
			int id=0;
			numbers=fillUpArray(numbers);
			// Creating node threads
			for(int i=0;i<3;i++){
				for(int j=0;j<3;j++){
				 hbtArray[i][j]=new HeartBeatThreads(id);
				 if(id==0|| id%2==1){
					 hbtArray[i][j].isodd=true;
				 }
				 else{
					 hbtArray[i][j].isodd=false; 
				 }
				 id++;
				 // Assign array to each node to sort
				 hbtArray[i][j].internalArray=Arrays.copyOfRange(numbers, bigIndex, length);
				 if(length<180){
					 bigIndex=length;
					 length=length+20;
					 
				 }
			
				}
			}
			allSorted= new AtomicBoolean[id];
			for(int i=0;i<id;i++){
				allSorted[i]=new AtomicBoolean(false);
			}
			// Assign neighbours to each node
			for(int i=0;i<3;i++){
				for(int j=0;j<3;j++){
					if(i==0 && j == 0){
						hbtArray[i][j].neighbours[0]= hbtArray[i][j+1];
						hbtArray[i][j].neighbours[1]= hbtArray[i+1][j];
						hbtArray[i][j].neighbours[2]= hbtArray[i][2];
					}
					if(i==0 && j == 1){
						hbtArray[i][j].neighbours[0]= hbtArray[i][j-1];
						hbtArray[i][j].neighbours[1]= hbtArray[i+1][j];
						hbtArray[i][j].neighbours[2]= hbtArray[i][j+1];
					}
					if(i==0 && j == 2){
						hbtArray[i][j].neighbours[0]= hbtArray[i][0];
						hbtArray[i][j].neighbours[1]= hbtArray[i+1][j-1];
						hbtArray[i][j].neighbours[2]= hbtArray[i+1][j];
					}
					if(i==1 && j == 0){
						hbtArray[i][j].neighbours[0]= hbtArray[i][2];
						hbtArray[i][j].neighbours[1]= hbtArray[i][j+1];
						hbtArray[i][j].neighbours[2]= hbtArray[i+1][j];
					}
					if(i==1 && j == 1){
						hbtArray[i][j].neighbours[0]= hbtArray[i][j+1];
						hbtArray[i][j].neighbours[1]= hbtArray[i][j-1];
						hbtArray[i][j].neighbours[2]= hbtArray[i+1][j];
					}
					if(i==1 && j == 2){
						hbtArray[i][j].neighbours[0]= hbtArray[i][0];
						hbtArray[i][j].neighbours[1]= hbtArray[i][j-1];
						hbtArray[i][j].neighbours[2]= hbtArray[i+1][j];
					}
					if(i==2 && j == 0){
						hbtArray[i][j].neighbours[0]= hbtArray[i][j+1];
						hbtArray[i][j].neighbours[1]= hbtArray[i-1][j];
						hbtArray[i][j].neighbours[2]= hbtArray[i][j+1];
					}
					if(i==2 && j == 1){
						hbtArray[i][j].neighbours[0]= hbtArray[i][j+1];
						hbtArray[i][j].neighbours[1]= hbtArray[i-1][j];
						hbtArray[i][j].neighbours[2]= hbtArray[0][j];
					}
					if(i==2 && j == 2){
						hbtArray[i][j].neighbours[0]= hbtArray[i][j-1];
						hbtArray[i][j].neighbours[1]= hbtArray[i-1][j];
						hbtArray[i][j].neighbours[2]= hbtArray[0][j];
					}
						
				}
			}
			for(int i=0;i<3;i++){
				for(int j=0;j<3;j++){
				 hbtArray[i][j].run();
				}
			}
			
		}
	// Fill array that each node shares	
	public Integer[] fillUpArray(Integer [] num){
			  ArrayList<Integer> list = new ArrayList<Integer>();
			  Integer[]nub= new Integer[180];
		        for (int i=0; i<num.length; i++) {
		            list.add(new Integer(i));
		        }
		        Collections.shuffle(list);
		        Object[] intObj=list.toArray();
		        for(int i=0;i<intObj.length;i++){
		        	nub[i]=(Integer)intObj[i];
		        }
		        return nub;
		}
	// The node thread object
	class HeartBeatThreads implements Runnable{
		Integer[] internalArray;
		Boolean running=true;
		int id;
		AtomicBoolean needTosort=new AtomicBoolean(false);
		AtomicBoolean sendSignal=new AtomicBoolean(false);
		AtomicBoolean receiveSignal=new AtomicBoolean(false);
		public Boolean isodd;
		
		HeartBeatThreads[]neighbours= new HeartBeatThreads[3];
		public HeartBeatThreads(int id){
			this.id=id;
		}

		public void run() {
			sortArray(internalArray);
			while(running){
				for(int i=0;i<neighbours.length;i++){
					if(isodd==true && neighbours[i].isodd ==false){
						int temp;
						int k=getFirstEvenIndex(internalArray);
						int j=getFirstOddIndex(neighbours[i].internalArray);
						if(k==-1){allSorted[id].set(true);}
						if(j==-1){
							allSorted[neighbours[i].id].set(true);
							break;
						}
						temp=neighbours[i].internalArray[j];
						neighbours[i].internalArray[j]=internalArray[k];
						internalArray[k]=temp;
						sortArray(internalArray);
						sortArray(neighbours[i].internalArray);
					}
					if(isodd==false && neighbours[i].isodd ==true){
						int temp;
						int k=getFirstOddIndex(internalArray);
						int j=getFirstEvenIndex(neighbours[i].internalArray);
						
						if(k==-1){allSorted[id].set(true);}
						if(j==-1){allSorted[neighbours[i].id].set(true);}
						temp=neighbours[i].internalArray[j];
						neighbours[i].internalArray[j]=internalArray[k];
						internalArray[k]=temp;
						sortArray(internalArray);
						sortArray(neighbours[i].internalArray);
					}
				}
			}
			
		}
		// to be used by each node to sort array in descending order
		synchronized public void sortArray(Integer[]a){
			int temp;
			 for (int i = 0; i < a.length; i++) 
		        {
		            for (int j = i + 1; j < a.length; j++) 
		            {
		                if (a[i] < a[j]) 
		                {
		                    temp = a[i];
		                    a[i] = a[j];
		                    a[j] = temp;
		                }
		            }
		        }
			
		}
		//if node is even sort out odd integer and send to an odd neighbour
		int getFirstOddIndex(Integer[] num){
			int k=0;
			for(int i=0;i<num.length;i++){
				if(num[i]%2==1){
					k=i;
					break;
				}
				else {
					k=0;
				}
			}
			return k;
		}
		//if node is odd sort out even integers and send to an even neighbor
		int getFirstEvenIndex(Integer[] num){
			int k=0;
			for(int i=0;i<num.length;i++){
				if(num[i]%2==0){
					k=i;
					break;
				}
				else
					k=0;
			}
			return k;
		}
		
	}
	public static void main(String[] args) throws InterruptedException{
		HeartBeatSort  hbs= new HeartBeatSort();
		int k=0; int counter=1;
		while(k==0){
			//  termination when all allSorted values are true
			for(int i=0;i<hbs.allSorted.length;i++){
				if(hbs.allSorted[i].get()== true){
					counter++;
					if(counter==9){
						k=1;
					}
				}
				else{
					counter=1;
				}
			}
		}
		for(int i=0;i<hbs.hbtArray.length;i++){
			for(int j=0;j<hbs.hbtArray[0].length;j++){
				hbs.hbtArray[i][j].running=false;
			}
		}
	}
	
}
