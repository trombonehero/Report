/**
 * Written by Stanley Uche Godfrey
 * A solution to
 * Assignment 2  Question of ENGI9869 Course
 * Java implementation of Dissemination of Barrier
 * */
package advancedConcurrentPackage;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.ReentrantLock;
public class MyThread {
	//public  Boolean[][] waitingFlags;
	public Integer[][] notificationFlags;
	public Integer waitingFlag[];
	int round,thread_Number,totalThreads,roundTotal;
	static int  counter=0;
	static ReentrantLock counterLock = new ReentrantLock(true);
	 
	CyclicBarrier barrier;
	public MyThread(int numberOfThreads){
		totalThreads=numberOfThreads;
		roundTotal=testPowerOfTwo(numberOfThreads);
		round=(int)(Math.log(roundTotal)/Math.log(2));
		 //waitingFlags=new Boolean[numberOfThreads][round];
		 notificationFlags=new Integer[numberOfThreads][round];
		 waitingFlag=new Integer[numberOfThreads];
		 for(int i=0;i<numberOfThreads;i++){
			 waitingFlag[i]=0;
		 }
		
	}
	public void createThreads(){
		barrier=new CyclicBarrier(totalThreads);
		for(int i=0;i<totalThreads;i++){
			
			new Thread(){
				public void run(){
					
			        
					for(int rnd=0;rnd<round;rnd++){
						notifyThread(counter,  rnd);
					}
					try {
						spinRound(counter);
					}
					catch (TimeoutException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					increaseCounter();
					
				}
				
			}.start();
			
		}
	}
	public void notifyThread(int i, int r){
		 
			int temp=(i-(int)Math.pow(2,r))%totalThreads;
            if(temp<0){
            	temp=temp+totalThreads;
            }
        	notificationFlags[i][r]=(i+(int)Math.pow(2,r))%totalThreads;
        	waitingFlag[temp]+=1;
    		System.out.println(Thread.currentThread().getName()+" has finished round " + r+
    				" waiting for others: ");
    		System.out.println("");
		
	}
	public void spinRound(int i) throws TimeoutException{
		if(waitingFlag[i]<round){
				
			try{
				barrier.await();
			}
			catch (InterruptedException e) {

	            System.out.println("Service one interrupted!");
	            e.printStackTrace();

	        } catch (BrokenBarrierException e) {

	            System.out.println("Service one interrupted!");
	            e.printStackTrace();

	        }
	        System.out.println(Thread.currentThread().getName()+" wait is over!");
	        System.out.println("");
	       
			
		}
	}
	int testPowerOfTwo(int y){
		
		while(y%4 !=0){
			y++;
				
		}
		
		return y;
	}
	public   void increaseCounter(){
		 counterLock.lock();

	        // Always good practice to enclose locks in a try-finally block
	        try{
	            //System.out.println(Thread.currentThread().getName() + ": " + counter);
	            counter++;
	        }
	        finally{
	             counterLock.unlock();
	        }
	     
		
		
	}
	
	public static void main(String[] args){
		MyThread test =new MyThread(6);
		test.createThreads();
	
		
		
	}
	
}
